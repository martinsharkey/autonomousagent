from langgraph.graph import StateGraph, START, END
from langgraph.types import RetryPolicy
from core.checkpointer import JSONCheckpointer
from core.state import AgentState
from agents.autobot import autobot_node
from agents.alpha_evaluator import alpha_node
from agents.beta_worker import beta_node
from core.semantic_cache import check_duplicate_invocation
from core.snapshots import capture_snapshot
from core.rollback import error_handler_node, compensate_node

local_retry = RetryPolicy(
    initial_interval=0.5,
    backoff_factor=2.0,
    max_attempts=3,
    jitter=True
)

def deterministic_router(state: AgentState) -> str:
    if state["loop_count"] >= 3:
        print(f"[SYSTEM OVERRIDE] TTL limit {state['loop_count']} breached. Terminating.")
        return "compensate"

    error_feedback = state.get("error_feedback") or []
    if error_feedback:
        last_error = error_feedback[-1]
        originating_node = last_error.get("node")
        if originating_node in ("autobot", "alpha_evaluator", "beta_worker"):
            print(f"[SYSTEM OVERRIDE] Error feedback from {originating_node}, routing back for self-correction.")
            return originating_node
        return "error_handler"

    last_message = state["messages"][-1].content

    if "EXECUTE_CODE" in last_message:
        return "beta_worker"

    if "REVIEW_REQUIRED" in last_message:
        return "alpha_evaluator"

    if "CONSENSUS_REACHED" in last_message:
        return END

    return "autobot"

def autobot_with_cache(state: AgentState):
    duplicate = check_duplicate_invocation(state)
    if duplicate:
        return {
            "messages": [{"role": "system", "content": "SYSTEM OVERRIDE: YOU HAVE ALREADY TRIED THIS ACTION AND IT FAILED."}],
            "loop_count": state["loop_count"] + 1
        }
    from core.rollback import capture_snapshot
    snapshot = capture_snapshot(state, "autobot")
    result = autobot_node(state)
    result["loop_count"] = state["loop_count"] + 1
    result["last_snapshot"] = snapshot
    return result

def alpha_with_cache(state: AgentState):
    duplicate = check_duplicate_invocation(state)
    if duplicate:
        return {
            "messages": [{"role": "system", "content": "SYSTEM OVERRIDE: YOU HAVE ALREADY TRIED THIS ACTION AND IT FAILED."}],
            "loop_count": state["loop_count"] + 1
        }
    from core.rollback import capture_snapshot
    snapshot = capture_snapshot(state, "alpha_evaluator")
    result = alpha_node(state)
    result["loop_count"] = state["loop_count"] + 1
    result["last_snapshot"] = snapshot
    return result

def beta_with_cache(state: AgentState):
    duplicate = check_duplicate_invocation(state)
    if duplicate:
        return {
            "messages": [{"role": "system", "content": "SYSTEM OVERRIDE: YOU HAVE ALREADY TRIED THIS ACTION AND IT FAILED."}],
            "loop_count": state["loop_count"] + 1
        }
    from core.rollback import capture_snapshot
    snapshot = capture_snapshot(state, "beta_worker")
    result = beta_node(state)
    result["loop_count"] = state["loop_count"] + 1
    result["last_snapshot"] = snapshot
    return result

workflow = StateGraph(AgentState)

workflow.add_node("autobot", autobot_with_cache, retry=local_retry)
workflow.add_node("alpha_evaluator", alpha_with_cache, retry=local_retry)
workflow.add_node("beta_worker", beta_with_cache, retry=local_retry)
workflow.add_node("compensate", compensate_node)
workflow.add_node("terminal_fallback", lambda state: {"messages": [{"role": "system", "content": "Task terminated due to loop limit."}]})
workflow.add_node("error_handler", error_handler_node)

workflow.add_edge(START, "autobot")

workflow.add_conditional_edges(
    "autobot",
    deterministic_router,
    {
        "autobot": "autobot",
        "beta_worker": "beta_worker",
        "alpha_evaluator": "alpha_evaluator",
        "compensate": "compensate",
        "terminal_fallback": "terminal_fallback",
        "error_handler": "error_handler",
        END: END
    }
)

workflow.add_edge("beta_worker", "autobot")
workflow.add_edge("alpha_evaluator", "autobot")
workflow.add_edge("error_handler", "autobot")
workflow.add_edge("compensate", END)

checkpointer = JSONCheckpointer(filepath="./checkpoints.json")
app = workflow.compile(checkpointer=checkpointer)
